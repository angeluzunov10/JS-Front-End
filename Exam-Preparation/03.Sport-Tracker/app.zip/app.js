// Get the DOM elements
const workoutInput = document.getElementById('workout');
const locationInput = document.getElementById('location');
const dateInput = document.getElementById('date');
const addWorkoutBtn = document.getElementById('add-workout');
const editWorkoutBtn = document.getElementById('edit-workout');
const listContainer = document.getElementById('list');

// Set the current workout ID for editing
let currentWorkoutId = null;

// Fetch all workouts from the server and display them
async function loadWorkouts() {
    try {
        const response = await fetch('http://localhost:3030/jsonstore/workout/');
        const data = await response.json();
        listContainer.innerHTML = '';  // Clear current list
        Object.values(data).forEach(workout => {
            const workoutElement = createWorkoutElement(workout);
            listContainer.appendChild(workoutElement);
        });
        editWorkoutBtn.disabled = true;
    } catch (error) {
        console.error('Error loading workouts:', error);
    }
}

// Create an HTML element for a workout
function createWorkoutElement(workout) {
    const workoutDiv = document.createElement('div');
    workoutDiv.classList.add('container');
    
    const workoutName = document.createElement('h2');
    workoutName.textContent = workout.workout;
    
    const workoutDate = document.createElement('h3');
    workoutDate.textContent = workout.date;
    
    const workoutLocation = document.createElement('h3');
    workoutLocation.textContent = workout.location;
    
    const buttonsContainer = document.createElement('div');
    buttonsContainer.id = 'buttons-container';

    const changeBtn = document.createElement('button');
    changeBtn.classList.add('change-btn');
    changeBtn.textContent = 'Change';
    changeBtn.addEventListener('click', () => editWorkout(workout));

    const doneBtn = document.createElement('button');
    doneBtn.classList.add('delete-btn');
    doneBtn.textContent = 'Done';
    doneBtn.addEventListener('click', () => deleteWorkout(workout._id));

    buttonsContainer.appendChild(changeBtn);
    buttonsContainer.appendChild(doneBtn);
    
    workoutDiv.appendChild(workoutName);
    workoutDiv.appendChild(workoutDate);
    workoutDiv.appendChild(workoutLocation);
    workoutDiv.appendChild(buttonsContainer);
    
    return workoutDiv;
}

// Edit a workout
function editWorkout(workout) {
    currentWorkoutId = workout._id;
    workoutInput.value = workout.workout;
    locationInput.value = workout.location;
    dateInput.value = workout.date;

    addWorkoutBtn.disabled = true;
    editWorkoutBtn.disabled = false;
}

// Add a new workout
async function addWorkout() {
    const workout = workoutInput.value.trim();
    const location = locationInput.value.trim();
    const date = dateInput.value.trim();

    if (workout && location && date) {
        const newWorkout = { workout, location, date };
        
        try {
            await fetch('http://localhost:3030/jsonstore/workout/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newWorkout)
            });
            loadWorkouts();
            resetForm();
        } catch (error) {
            console.error('Error adding workout:', error);
        }
    }
}

// Edit a workout on the server
async function editWorkoutOnServer() {
    const workout = workoutInput.value.trim();
    const location = locationInput.value.trim();
    const date = dateInput.value.trim();

    if (workout && location && date) {
        const updatedWorkout = { workout, location, date };

        try {
            await fetch(`http://localhost:3030/jsonstore/workout/${currentWorkoutId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(updatedWorkout)
            });
            loadWorkouts();
            resetForm();
        } catch (error) {
            console.error('Error editing workout:', error);
        }
    }
}

// Delete a workout
async function deleteWorkout(workoutId) {
    try {
        await fetch(`http://localhost:3030/jsonstore/workout/${workoutId}`, {
            method: 'DELETE',
        });
        loadWorkouts();
    } catch (error) {
        console.error('Error deleting workout:', error);
    }
}

// Reset the form
function resetForm() {
    workoutInput.value = '';
    locationInput.value = '';
    dateInput.value = '';
    addWorkoutBtn.disabled = false;
    editWorkoutBtn.disabled = true;
    currentWorkoutId = null;
}

// Event listeners
addWorkoutBtn.addEventListener('click', (e) => {
    e.preventDefault();
    if (currentWorkoutId) {
        editWorkoutOnServer();
    } else {
        addWorkout();
    }
});

editWorkoutBtn.addEventListener('click', (e) => {
    e.preventDefault();
    editWorkoutOnServer();
});

// Load workouts when the page loads
window.addEventListener('load', loadWorkouts);
